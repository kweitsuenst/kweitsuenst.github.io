document.getElementById("quizBtn").addEventListener("click", function() {
    document.getElementById("quizQuestion").style.display = "block";
    document.getElementById("answerBtn").style.display = "block";
});
document.getElementById("answerBtn").addEventListener("click", function() {
    document.getElementById("answerText").style.display = "block";
});
